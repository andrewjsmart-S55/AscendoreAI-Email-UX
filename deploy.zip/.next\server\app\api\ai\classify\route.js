"use strict";(()=>{var e={};e.id=388,e.ids=[388],e.modules={517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},3017:(e,t,r)=>{r.r(t),r.d(t,{headerHooks:()=>y,originalPathname:()=>A,patchFetch:()=>P,requestAsyncStorage:()=>m,routeModule:()=>d,serverHooks:()=>g,staticGenerationAsyncStorage:()=>f,staticGenerationBailout:()=>h});var a={};r.r(a),r.d(a,{POST:()=>p});var n=r(5419),o=r(9108),i=r(9678),s=r(8070),c=r(3231);let u=null,l=`You are an email classification assistant. Analyze the following email and provide a classification.

Email:
From: {from}
Subject: {subject}
Body: {body}

Respond in JSON format:
{
  "category": "urgent" | "important" | "routine" | "promotional" | "newsletter" | "automated" | "social" | "spam",
  "intent": "request" | "action_required" | "information" | "fyi" | "social" | "transactional" | "marketing",
  "sentiment": "positive" | "neutral" | "negative",
  "topics": ["topic1", "topic2"],
  "urgency": "high" | "medium" | "low" | "none",
  "requiresResponse": true | false,
  "hasDeadline": true | false,
  "deadline": "extracted deadline or null",
  "isSpam": true | false,
  "isPhishing": true | false,
  "confidence": 0.0-1.0
}`;async function p(e){try{if(!process.env.OPENAI_API_KEY)return s.Z.json({error:"OpenAI API key not configured"},{status:500});let{from:t,subject:r,body:a}=await e.json();if(!t||!r)return s.Z.json({error:"from and subject are required"},{status:400});let n=l.replace("{from}",t).replace("{subject}",r).replace("{body}",(a||"").substring(0,2e3)),o=await (function(){if(!u&&process.env.OPENAI_API_KEY&&(u=new c.ZP({apiKey:process.env.OPENAI_API_KEY})),!u)throw Error("OpenAI API key not configured");return u})().chat.completions.create({model:"gpt-4o-mini",messages:[{role:"user",content:n}],temperature:.3,max_tokens:500,response_format:{type:"json_object"}}),i=o.choices[0]?.message?.content||"{}";try{let e=JSON.parse(i);return s.Z.json({...e,model:o.model,usage:o.usage})}catch{return s.Z.json({category:"routine",intent:"information",sentiment:"neutral",topics:[],urgency:"none",requiresResponse:!1,hasDeadline:!1,isSpam:!1,isPhishing:!1,confidence:.3,error:"Failed to parse classification"})}}catch(e){return console.error("[AI Classify API] Error:",e),s.Z.json({error:"Classification failed"},{status:500})}}let d=new n.AppRouteRouteModule({definition:{kind:o.x.APP_ROUTE,page:"/api/ai/classify/route",pathname:"/api/ai/classify",filename:"route",bundlePath:"app/api/ai/classify/route"},resolvedPagePath:"C:\\Users\\AndrewSmart\\Claude_Projects\\AscendoreAI-Email-UX\\src\\app\\api\\ai\\classify\\route.ts",nextConfigOutput:"",userland:a}),{requestAsyncStorage:m,staticGenerationAsyncStorage:f,serverHooks:g,headerHooks:y,staticGenerationBailout:h}=d,A="/api/ai/classify/route";function P(){return(0,i.patchFetch)({serverHooks:g,staticGenerationAsyncStorage:f})}}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[638,289],()=>r(3017));module.exports=a})();
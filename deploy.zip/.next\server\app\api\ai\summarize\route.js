"use strict";(()=>{var e={};e.id=898,e.ids=[898],e.modules={517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},3277:(e,r,t)=>{t.r(r),t.d(r,{headerHooks:()=>f,originalPathname:()=>b,patchFetch:()=>A,requestAsyncStorage:()=>p,routeModule:()=>l,serverHooks:()=>h,staticGenerationAsyncStorage:()=>y,staticGenerationBailout:()=>g});var a={};t.r(a),t.d(a,{POST:()=>d});var s=t(5419),o=t(9108),i=t(9678),n=t(8070),m=t(3231);let u=null,c={email:`Summarize this email in 2-3 sentences, focusing on the key message and any action items.

From: {from}
Subject: {subject}
Body: {body}

Respond in JSON format:
{
  "summary": "Your summary here",
  "keyPoints": ["point1", "point2"],
  "actionItems": ["action1", "action2"]
}`,thread:`Summarize this email conversation thread. Include:
- The main topic/purpose
- Key decisions or outcomes
- Any pending action items
- Current status

Thread:
{thread}

Respond in JSON format:
{
  "summary": "Your summary here",
  "keyPoints": ["point1", "point2"],
  "actionItems": ["action1", "action2"],
  "status": "resolved" | "pending" | "needs_response"
}`,daily:`Create a brief daily email summary for these {count} emails.
Group by priority and highlight urgent items.

Emails:
{emails}

Respond in JSON format:
{
  "summary": "Brief overview of the day's emails",
  "urgent": ["urgent item 1"],
  "important": ["important item 1"],
  "actionRequired": ["action 1"],
  "fyi": ["fyi item 1"],
  "stats": {
    "total": number,
    "urgent": number,
    "needsResponse": number
  }
}`};async function d(e){try{let r;if(!process.env.OPENAI_API_KEY)return n.Z.json({error:"OpenAI API key not configured"},{status:500});let{type:t="email",from:a,subject:s,body:o,thread:i,emails:d}=await e.json();switch(t){case"email":if(!a||!s)return n.Z.json({error:"from and subject are required for email summary"},{status:400});r=c.email.replace("{from}",a).replace("{subject}",s).replace("{body}",(o||"").substring(0,3e3));break;case"thread":if(!i)return n.Z.json({error:"thread is required for thread summary"},{status:400});r=c.thread.replace("{thread}",i.substring(0,5e3));break;case"daily":if(!d||!Array.isArray(d))return n.Z.json({error:"emails array is required for daily summary"},{status:400});let l=d.slice(0,20).map((e,r)=>`${r+1}. From: ${e.from}, Subject: ${e.subject}`).join("\n");r=c.daily.replace("{count}",d.length.toString()).replace("{emails}",l);break;default:return n.Z.json({error:"Invalid summary type"},{status:400})}let p=await (function(){if(!u&&process.env.OPENAI_API_KEY&&(u=new m.ZP({apiKey:process.env.OPENAI_API_KEY})),!u)throw Error("OpenAI API key not configured");return u})().chat.completions.create({model:"gpt-4o-mini",messages:[{role:"user",content:r}],temperature:.3,max_tokens:800,response_format:{type:"json_object"}}),y=p.choices[0]?.message?.content||"{}";try{let e=JSON.parse(y);return n.Z.json({type:t,...e,model:p.model,usage:p.usage,generatedAt:new Date().toISOString()})}catch{return n.Z.json({type:t,summary:"Unable to generate summary.",keyPoints:[],actionItems:[],error:"Failed to parse summary"})}}catch(e){return console.error("[AI Summarize API] Error:",e),n.Z.json({error:"Summarization failed"},{status:500})}}let l=new s.AppRouteRouteModule({definition:{kind:o.x.APP_ROUTE,page:"/api/ai/summarize/route",pathname:"/api/ai/summarize",filename:"route",bundlePath:"app/api/ai/summarize/route"},resolvedPagePath:"C:\\Users\\AndrewSmart\\Claude_Projects\\AscendoreAI-Email-UX\\src\\app\\api\\ai\\summarize\\route.ts",nextConfigOutput:"",userland:a}),{requestAsyncStorage:p,staticGenerationAsyncStorage:y,serverHooks:h,headerHooks:f,staticGenerationBailout:g}=l,b="/api/ai/summarize/route";function A(){return(0,i.patchFetch)({serverHooks:h,staticGenerationAsyncStorage:y})}}};var r=require("../../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),a=r.X(0,[638,289],()=>t(3277));module.exports=a})();